function hi() {
  console.log("Hello World!");
}
hi();
module.exports = [{
  command: ["1917style"],
  operate: async ({
    m: _0xdcb250,
    args: _0x264e81,
    reply: _0x5e1fab,
    Cypher: _0x3615dd,
    prefix: _0x509f54,
    mess: _0x4e63f5,
    ephoto: _0x1f590a
  }) => {
    let _0x369675 = _0x264e81.join(" ");
    if (!_0x369675) {
      return _0x5e1fab("*Example: " + _0x509f54 + "1917style Matrix*");
    }
    const _0x5c630b = "https://en.ephoto360.com/1917-style-text-effect-523.html";
    try {
      let _0x326ea6 = await _0x1f590a(_0x5c630b, _0x369675);
      await _0x3615dd.sendMessage(_0xdcb250.chat, {
        image: {
          url: _0x326ea6
        },
        caption: "" + _0x4e63f5.success
      }, {
        quoted: _0xdcb250
      });
    } catch (_0x525818) {
      console.error("Error in 1917style command:", _0x525818);
      _0x5e1fab("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["advancedglow"],
  operate: async ({
    m: _0x3884ff,
    args: _0x2d23de,
    reply: _0x49ce10,
    Cypher: _0x1d4b7e,
    prefix: _0x562bd9,
    mess: _0x52de24,
    ephoto: _0x2badd7
  }) => {
    let _0x41b88a = _0x2d23de.join(" ");
    if (!_0x41b88a) {
      return _0x49ce10("*Example: " + _0x562bd9 + "advancedglow Matrix*");
    }
    const _0xd78fd2 = "https://en.ephoto360.com/advanced-glow-effects-74.html";
    try {
      let _0x3c810d = await _0x2badd7(_0xd78fd2, _0x41b88a);
      await _0x1d4b7e.sendMessage(_0x3884ff.chat, {
        image: {
          url: _0x3c810d
        },
        caption: "" + _0x52de24.success
      }, {
        quoted: _0x3884ff
      });
    } catch (_0x2265fb) {
      console.error("Error in advancedglow command:", _0x2265fb);
      _0x49ce10("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["blackpinklogo"],
  operate: async ({
    m: _0x2c4dae,
    args: _0x4cb28b,
    reply: _0x1f5509,
    Cypher: _0x2b9343,
    prefix: _0x236455,
    mess: _0x23b132,
    ephoto: _0x1b0cdf
  }) => {
    let _0x5260ba = _0x4cb28b.join(" ");
    if (!_0x5260ba) {
      return _0x1f5509("*Example: " + _0x236455 + "blackpinklogo Matrix*");
    }
    const _0x1019bc = "https://en.ephoto360.com/create-blackpink-logo-online-free-607.html";
    try {
      let _0xb6874c = await _0x1b0cdf(_0x1019bc, _0x5260ba);
      await _0x2b9343.sendMessage(_0x2c4dae.chat, {
        image: {
          url: _0xb6874c
        },
        caption: "" + _0x23b132.success
      }, {
        quoted: _0x2c4dae
      });
    } catch (_0x49fac2) {
      console.error("Error in blackpinklogo command:", _0x49fac2);
      _0x1f5509("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["blackpinkstyle"],
  operate: async ({
    m: _0x28db11,
    args: _0x11154e,
    reply: _0x504b76,
    Cypher: _0x56de40,
    prefix: _0x4ed99e,
    mess: _0x5dab81,
    ephoto: _0x4d2065
  }) => {
    let _0x34f66d = _0x11154e.join(" ");
    if (!_0x34f66d) {
      return _0x504b76("*Example: " + _0x4ed99e + "blackpinkstyle Matrix*");
    }
    const _0x2988bb = "https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html";
    try {
      let _0x175794 = await _0x4d2065(_0x2988bb, _0x34f66d);
      await _0x56de40.sendMessage(_0x28db11.chat, {
        image: {
          url: _0x175794
        },
        caption: "" + _0x5dab81.success
      }, {
        quoted: _0x28db11
      });
    } catch (_0x5aef1c) {
      console.error("Error in blackpinkstyle command:", _0x5aef1c);
      _0x504b76("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["cartoonstyle"],
  operate: async ({
    m: _0xe81526,
    args: _0x4ab204,
    reply: _0x1f1dd0,
    Cypher: _0x182751,
    prefix: _0x416fb9,
    mess: _0x3eb116,
    ephoto: _0x2ac1ca
  }) => {
    let _0x1d3647 = _0x4ab204.join(" ");
    if (!_0x1d3647) {
      return _0x1f1dd0("*Example: " + _0x416fb9 + "cartoonstyle Matrix*");
    }
    const _0x509656 = "https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html";
    try {
      let _0x251d34 = await _0x2ac1ca(_0x509656, _0x1d3647);
      await _0x182751.sendMessage(_0xe81526.chat, {
        image: {
          url: _0x251d34
        },
        caption: "" + _0x3eb116.success
      }, {
        quoted: _0xe81526
      });
    } catch (_0x124ef4) {
      console.error("Error in cartoonstyle command:", _0x124ef4);
      _0x1f1dd0("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["deadpool"],
  operate: async ({
    m: _0x2f7f90,
    args: _0x70dec3,
    reply: _0x1e483c,
    Cypher: _0x264322,
    prefix: _0x5a52fd,
    mess: _0x1b7e94,
    ephoto: _0x37e3c0
  }) => {
    let _0x2f8492 = _0x70dec3.join(" ");
    if (!_0x2f8492) {
      return _0x1e483c("*Example: " + _0x5a52fd + "deadpool Matrix*");
    }
    const _0x1351aa = "https://en.ephoto360.com/create-light-effects-green-neon-online-429.html";
    try {
      let _0x3500eb = await _0x37e3c0(_0x1351aa, _0x2f8492);
      await _0x264322.sendMessage(_0x2f7f90.chat, {
        image: {
          url: _0x3500eb
        },
        caption: "" + _0x1b7e94.success
      }, {
        quoted: _0x2f7f90
      });
    } catch (_0xafa55) {
      console.error("Error in deadpool command:", _0xafa55);
      _0x1e483c("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["deletingtext"],
  operate: async ({
    m: _0x4718e5,
    args: _0x42458e,
    reply: _0x32beea,
    Cypher: _0x1cf55f,
    prefix: _0x17cfe7,
    mess: _0x577105,
    ephoto: _0x5a8cc6
  }) => {
    let _0x43e07f = _0x42458e.join(" ");
    if (!_0x43e07f) {
      return _0x32beea("*Example: " + _0x17cfe7 + "deletingtext Matrix*");
    }
    const _0x334f34 = "https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html";
    try {
      let _0xb1cd7a = await _0x5a8cc6(_0x334f34, _0x43e07f);
      await _0x1cf55f.sendMessage(_0x4718e5.chat, {
        image: {
          url: _0xb1cd7a
        },
        caption: "" + _0x577105.success
      }, {
        quoted: _0x4718e5
      });
    } catch (_0x48da2c) {
      console.error("Error in deletingtext command:", _0x48da2c);
      _0x32beea("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["dragonball"],
  operate: async ({
    m: _0x5b59ba,
    args: _0x5f5704,
    reply: _0x1f5979,
    Cypher: _0x312cd3,
    prefix: _0x5b840f,
    mess: _0x3bebf0,
    ephoto: _0x27fce3
  }) => {
    let _0x1eabd5 = _0x5f5704.join(" ");
    if (!_0x1eabd5) {
      return _0x1f5979("*Example: " + _0x5b840f + "dragonball Matrix*");
    }
    const _0x72e5ca = "https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html";
    try {
      let _0x5c7533 = await _0x27fce3(_0x72e5ca, _0x1eabd5);
      await _0x312cd3.sendMessage(_0x5b59ba.chat, {
        image: {
          url: _0x5c7533
        },
        caption: "" + _0x3bebf0.success
      }, {
        quoted: _0x5b59ba
      });
    } catch (_0x549142) {
      console.error("Error in dragonball command:", _0x549142);
      _0x1f5979("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["effectclouds"],
  operate: async ({
    m: _0x1eb3dc,
    args: _0x1230e5,
    reply: _0x42f17b,
    Cypher: _0xa9a567,
    prefix: _0x559d85,
    mess: _0x2f903f,
    ephoto: _0x53b233
  }) => {
    let _0xbad842 = _0x1230e5.join(" ");
    if (!_0xbad842) {
      return _0x42f17b("*Example: " + _0x559d85 + "effectclouds Matrix*");
    }
    const _0x484dfe = "https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html";
    try {
      let _0xa10eeb = await _0x53b233(_0x484dfe, _0xbad842);
      await _0xa9a567.sendMessage(_0x1eb3dc.chat, {
        image: {
          url: _0xa10eeb
        },
        caption: "" + _0x2f903f.success
      }, {
        quoted: _0x1eb3dc
      });
    } catch (_0x2e0a01) {
      console.error("Error in effectclouds command:", _0x2e0a01);
      _0x42f17b("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["flag3dtext"],
  operate: async ({
    m: _0x28a922,
    args: _0x22fa8d,
    reply: _0x436e74,
    Cypher: _0x2fa8a1,
    prefix: _0x4b7351,
    mess: _0x3891c7,
    ephoto: _0x558af5
  }) => {
    let _0x1150a7 = _0x22fa8d.join(" ");
    if (!_0x1150a7) {
      return _0x436e74("*Example: " + _0x4b7351 + "flag3dtext Matrix*");
    }
    const _0x18a525 = "https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html";
    try {
      let _0x205dcf = await _0x558af5(_0x18a525, _0x1150a7);
      await _0x2fa8a1.sendMessage(_0x28a922.chat, {
        image: {
          url: _0x205dcf
        },
        caption: "" + _0x3891c7.success
      }, {
        quoted: _0x28a922
      });
    } catch (_0x182dec) {
      console.error("Error in flag3dtext command:", _0x182dec);
      _0x436e74("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["flagtext"],
  operate: async ({
    m: _0x6498cf,
    args: _0x40f137,
    reply: _0x530872,
    Cypher: _0x1c9657,
    prefix: _0x377b3d,
    mess: _0x247433,
    ephoto: _0x5a28b1
  }) => {
    let _0x759718 = _0x40f137.join(" ");
    if (!_0x759718) {
      return _0x530872("*Example: " + _0x377b3d + "flagtext Matrix*");
    }
    const _0x2a6b6f = "https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html";
    try {
      let _0x1d5d20 = await _0x5a28b1(_0x2a6b6f, _0x759718);
      await _0x1c9657.sendMessage(_0x6498cf.chat, {
        image: {
          url: _0x1d5d20
        },
        caption: "" + _0x247433.success
      }, {
        quoted: _0x6498cf
      });
    } catch (_0x527630) {
      console.error("Error in flagtext command:", _0x527630);
      _0x530872("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["freecreate"],
  operate: async ({
    m: _0x24fa0f,
    args: _0x223110,
    reply: _0x5803fa,
    Cypher: _0x30fc9f,
    prefix: _0x5f152f,
    mess: _0x464c41,
    ephoto: _0x3321b3
  }) => {
    let _0x4582fe = _0x223110.join(" ");
    if (!_0x4582fe) {
      return _0x5803fa("*Example: " + _0x5f152f + "freecreate Matrix*");
    }
    const _0x1adaaa = "https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html";
    try {
      let _0x1ed07c = await _0x3321b3(_0x1adaaa, _0x4582fe);
      await _0x30fc9f.sendMessage(_0x24fa0f.chat, {
        image: {
          url: _0x1ed07c
        },
        caption: "" + _0x464c41.success
      }, {
        quoted: _0x24fa0f
      });
    } catch (_0xdd7731) {
      console.error("Error in freecreate command:", _0xdd7731);
      _0x5803fa("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["galaxystyle"],
  operate: async ({
    m: _0x215ac4,
    args: _0x11d56e,
    reply: _0x1e8b49,
    Cypher: _0x3f7f27,
    prefix: _0x3d79c3,
    mess: _0x3c58cf,
    ephoto: _0x259f78
  }) => {
    let _0x5d2459 = _0x11d56e.join(" ");
    if (!_0x5d2459) {
      return _0x1e8b49("*Example: " + _0x3d79c3 + "galaxystyle Matrix*");
    }
    const _0x3e2291 = "https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html";
    try {
      let _0x61bf5e = await _0x259f78(_0x3e2291, _0x5d2459);
      await _0x3f7f27.sendMessage(_0x215ac4.chat, {
        image: {
          url: _0x61bf5e
        },
        caption: "" + _0x3c58cf.success
      }, {
        quoted: _0x215ac4
      });
    } catch (_0x50f651) {
      console.error("Error in galaxystyle command:", _0x50f651);
      _0x1e8b49("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["galaxywallpaper"],
  operate: async ({
    m: _0x4fcc5f,
    args: _0x13fda7,
    reply: _0x11c3e3,
    Cypher: _0x1cd203,
    prefix: _0x3a9960,
    mess: _0x2d6698,
    ephoto: _0x2503b5
  }) => {
    let _0x3da821 = _0x13fda7.join(" ");
    if (!_0x3da821) {
      return _0x11c3e3("*Example: " + _0x3a9960 + "galaxywallpaper Matrix*");
    }
    const _0x27a07c = "https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html";
    try {
      let _0x473521 = await _0x2503b5(_0x27a07c, _0x3da821);
      await _0x1cd203.sendMessage(_0x4fcc5f.chat, {
        image: {
          url: _0x473521
        },
        caption: "" + _0x2d6698.success
      }, {
        quoted: _0x4fcc5f
      });
    } catch (_0xe14840) {
      console.error("Error in galaxywallpaper command:", _0xe14840);
      _0x11c3e3("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["glitchtext"],
  operate: async ({
    m: _0x23e518,
    args: _0x4bd074,
    reply: _0x5bb2af,
    Cypher: _0x3a742f,
    prefix: _0xa53a82,
    mess: _0x3add68,
    ephoto: _0x456b00
  }) => {
    let _0x695acf = _0x4bd074.join(" ");
    if (!_0x695acf) {
      return _0x5bb2af("*Example: " + _0xa53a82 + "glitchtext Matrix*");
    }
    const _0x1218f4 = "https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html";
    try {
      let _0xd8677f = await _0x456b00(_0x1218f4, _0x695acf);
      await _0x3a742f.sendMessage(_0x23e518.chat, {
        image: {
          url: _0xd8677f
        },
        caption: "" + _0x3add68.success
      }, {
        quoted: _0x23e518
      });
    } catch (_0x358046) {
      console.error("Error in glitchtext command:", _0x358046);
      _0x5bb2af("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["glowingtext"],
  operate: async ({
    m: _0x4279fc,
    args: _0x976a56,
    reply: _0x5595f0,
    Cypher: _0x5784fc,
    prefix: _0x17c9e4,
    mess: _0x48330b,
    ephoto: _0x580288
  }) => {
    let _0x332441 = _0x976a56.join(" ");
    if (!_0x332441) {
      return _0x5595f0("*Example: " + _0x17c9e4 + "glowingtext Matrix*");
    }
    const _0x110c54 = "https://en.ephoto360.com/create-glowing-text-effects-online-706.html";
    try {
      let _0x4ddb7d = await _0x580288(_0x110c54, _0x332441);
      await _0x5784fc.sendMessage(_0x4279fc.chat, {
        image: {
          url: _0x4ddb7d
        },
        caption: "" + _0x48330b.success
      }, {
        quoted: _0x4279fc
      });
    } catch (_0x286b27) {
      console.error("Error in glowingtext command:", _0x286b27);
      _0x5595f0("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["gradienttext"],
  operate: async ({
    m: _0x1ba7ff,
    args: _0x55a559,
    reply: _0x3660b7,
    Cypher: _0x161884,
    prefix: _0x7020a1,
    mess: _0x11f599,
    ephoto: _0x15de78
  }) => {
    let _0x36e615 = _0x55a559.join(" ");
    if (!_0x36e615) {
      return _0x3660b7("*Example: " + _0x7020a1 + "gradienttext Matrix*");
    }
    const _0x269cbf = "https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html";
    try {
      let _0x55fec2 = await _0x15de78(_0x269cbf, _0x36e615);
      await _0x161884.sendMessage(_0x1ba7ff.chat, {
        image: {
          url: _0x55fec2
        },
        caption: "" + _0x11f599.success
      }, {
        quoted: _0x1ba7ff
      });
    } catch (_0x3a3d1b) {
      console.error("Error in gradienttext command:", _0x3a3d1b);
      _0x3660b7("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["graffiti"],
  operate: async ({
    m: _0x37e0be,
    args: _0x4e8569,
    reply: _0x4fd102,
    Cypher: _0xc9b5b3,
    prefix: _0x782e4a,
    mess: _0x2b4e10,
    ephoto: _0x11fe6f
  }) => {
    let _0x8c7b4c = _0x4e8569.join(" ");
    if (!_0x8c7b4c) {
      return _0x4fd102("*Example: " + _0x782e4a + "graffiti Matrix*");
    }
    const _0x5d96c7 = "https://en.ephoto360.com/cute-girl-painting-graffiti-text-effect-667.html";
    try {
      let _0x549655 = await _0x11fe6f(_0x5d96c7, _0x8c7b4c);
      await _0xc9b5b3.sendMessage(_0x37e0be.chat, {
        image: {
          url: _0x549655
        },
        caption: "" + _0x2b4e10.success
      }, {
        quoted: _0x37e0be
      });
    } catch (_0x39c48c) {
      console.error("Error in graffiti command:", _0x39c48c);
      _0x4fd102("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["incandescent"],
  operate: async ({
    m: _0x2c8169,
    args: _0x1e4ad1,
    reply: _0x2b9f68,
    Cypher: _0x172f23,
    prefix: _0x4004b0,
    mess: _0x4c697b,
    ephoto: _0x32cfc4
  }) => {
    let _0x48df25 = _0x1e4ad1.join(" ");
    if (!_0x48df25) {
      return _0x2b9f68("*Example: " + _0x4004b0 + "incandescent Matrix*");
    }
    const _0x25f8cd = "https://en.ephoto360.com/text-effects-incandescent-bulbs-219.html";
    try {
      let _0x955501 = await _0x32cfc4(_0x25f8cd, _0x48df25);
      await _0x172f23.sendMessage(_0x2c8169.chat, {
        image: {
          url: _0x955501
        },
        caption: "" + _0x4c697b.success
      }, {
        quoted: _0x2c8169
      });
    } catch (_0x499492) {
      console.error("Error in incandescent command:", _0x499492);
      _0x2b9f68("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["lighteffects"],
  operate: async ({
    m: _0x1553cb,
    args: _0x407ecf,
    reply: _0x421e31,
    Cypher: _0x785f84,
    prefix: _0xd34d5e,
    mess: _0x5cd83d,
    ephoto: _0x4e2448
  }) => {
    let _0x1e1890 = _0x407ecf.join(" ");
    if (!_0x1e1890) {
      return _0x421e31("*Example: " + _0xd34d5e + "lighteffects Matrix*");
    }
    const _0x1c7daa = "https://en.ephoto360.com/create-light-effects-green-neon-online-429.html";
    try {
      let _0x4b15e8 = await _0x4e2448(_0x1c7daa, _0x1e1890);
      await _0x785f84.sendMessage(_0x1553cb.chat, {
        image: {
          url: _0x4b15e8
        },
        caption: "" + _0x5cd83d.success
      }, {
        quoted: _0x1553cb
      });
    } catch (_0x2c92f5) {
      console.error("Error in lighteffects command:", _0x2c92f5);
      _0x421e31("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["logomaker"],
  operate: async ({
    m: _0x2eed76,
    args: _0x173e68,
    reply: _0x4dd579,
    Cypher: _0x525488,
    prefix: _0x2c1ee0,
    mess: _0x2f6da1,
    ephoto: _0x528db9
  }) => {
    let _0x4df174 = _0x173e68.join(" ");
    if (!_0x4df174) {
      return _0x4dd579("*Example: " + _0x2c1ee0 + "logomaker Matrix*");
    }
    const _0x330f03 = "https://en.ephoto360.com/free-bear-logo-maker-online-673.html";
    try {
      let _0x45a67e = await _0x528db9(_0x330f03, _0x4df174);
      await _0x525488.sendMessage(_0x2eed76.chat, {
        image: {
          url: _0x45a67e
        },
        caption: "" + _0x2f6da1.success
      }, {
        quoted: _0x2eed76
      });
    } catch (_0x27894c) {
      console.error("Error in logomaker command:", _0x27894c);
      _0x4dd579("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["luxurygold"],
  operate: async ({
    m: _0x4b4390,
    args: _0x3c541a,
    reply: _0x3b9d14,
    Cypher: _0x3632b9,
    prefix: _0x4e057f,
    mess: _0x2bf9ee,
    ephoto: _0x22d244
  }) => {
    let _0x5c22cb = _0x3c541a.join(" ");
    if (!_0x5c22cb) {
      return _0x3b9d14("*Example: " + _0x4e057f + "luxurygold Matrix*");
    }
    const _0x1bf191 = "https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html";
    try {
      let _0x1a89d5 = await _0x22d244(_0x1bf191, _0x5c22cb);
      await _0x3632b9.sendMessage(_0x4b4390.chat, {
        image: {
          url: _0x1a89d5
        },
        caption: "" + _0x2bf9ee.success
      }, {
        quoted: _0x4b4390
      });
    } catch (_0x2c9881) {
      console.error("Error in luxurygold command:", _0x2c9881);
      _0x3b9d14("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["makingneon"],
  operate: async ({
    m: _0x6ed89a,
    args: _0x51b0c1,
    reply: _0x51d899,
    Cypher: _0x414ef7,
    prefix: _0x5a5a13,
    mess: _0x116b05,
    ephoto: _0x212123
  }) => {
    let _0x303454 = _0x51b0c1.join(" ");
    if (!_0x303454) {
      return _0x51d899("*Example: " + _0x5a5a13 + "makingneon Matrix*");
    }
    const _0x5b9f5a = "https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html";
    try {
      let _0x175f4d = await _0x212123(_0x5b9f5a, _0x303454);
      await _0x414ef7.sendMessage(_0x6ed89a.chat, {
        image: {
          url: _0x175f4d
        },
        caption: "" + _0x116b05.success
      }, {
        quoted: _0x6ed89a
      });
    } catch (_0x5b268f) {
      console.error("Error in makingneon command:", _0x5b268f);
      _0x51d899("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["matrix"],
  operate: async ({
    m: _0x188aef,
    args: _0x5948df,
    reply: _0x48d49e,
    Cypher: _0x22fece,
    prefix: _0x46bfa7,
    mess: _0x5d05cd,
    ephoto: _0x10daaf
  }) => {
    let _0x29013d = _0x5948df.join(" ");
    if (!_0x29013d) {
      return _0x48d49e("*Example: " + _0x46bfa7 + "matrix Malvin*");
    }
    const _0x11bb03 = "https://en.ephoto360.com/matrix-text-effect-154.html";
    try {
      let _0x31d75c = await _0x10daaf(_0x11bb03, _0x29013d);
      await _0x22fece.sendMessage(_0x188aef.chat, {
        image: {
          url: _0x31d75c
        },
        caption: "" + _0x5d05cd.success
      }, {
        quoted: _0x188aef
      });
    } catch (_0x3f8755) {
      console.error("Error in matrix command:", _0x3f8755);
      _0x48d49e("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["multicoloredneon"],
  operate: async ({
    m: _0x5153aa,
    args: _0x392677,
    reply: _0x30642e,
    Cypher: _0x1b5df2,
    prefix: _0x2ab3bc,
    mess: _0x30e407,
    ephoto: _0x358a95
  }) => {
    let _0x5d1bdf = _0x392677.join(" ");
    if (!_0x5d1bdf) {
      return _0x30642e("*Example: " + _0x2ab3bc + "multicoloredneon Matrix*");
    }
    const _0x3808a5 = "https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html";
    try {
      let _0x115f0b = await _0x358a95(_0x3808a5, _0x5d1bdf);
      await _0x1b5df2.sendMessage(_0x5153aa.chat, {
        image: {
          url: _0x115f0b
        },
        caption: "" + _0x30e407.success
      }, {
        quoted: _0x5153aa
      });
    } catch (_0x16cfd1) {
      console.error("Error in multicoloredneon command:", _0x16cfd1);
      _0x30642e("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["neonglitch"],
  operate: async ({
    m: _0x4635e0,
    args: _0x1b5514,
    reply: _0x48ce1b,
    Cypher: _0x2e80bc,
    prefix: _0x16864d,
    mess: _0x440f0b,
    ephoto: _0x5c493d
  }) => {
    let _0x2a7ca9 = _0x1b5514.join(" ");
    if (!_0x2a7ca9) {
      return _0x48ce1b("*Example: " + _0x16864d + "neonglitch Matrix*");
    }
    const _0x34013a = "https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html";
    try {
      let _0x52a454 = await _0x5c493d(_0x34013a, _0x2a7ca9);
      await _0x2e80bc.sendMessage(_0x4635e0.chat, {
        image: {
          url: _0x52a454
        },
        caption: "" + _0x440f0b.success
      }, {
        quoted: _0x4635e0
      });
    } catch (_0x2bec2a) {
      console.error("Error in neonglitch command:", _0x2bec2a);
      _0x48ce1b("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["papercutstyle"],
  operate: async ({
    m: _0x22febc,
    args: _0x6aee61,
    reply: _0x408906,
    Cypher: _0x2e97f5,
    prefix: _0xfa88d8,
    mess: _0x4528ad,
    ephoto: _0x161008
  }) => {
    let _0x435ae3 = _0x6aee61.join(" ");
    if (!_0x435ae3) {
      return _0x408906("*Example: " + _0xfa88d8 + "papercutstyle Matrix*");
    }
    const _0x19e318 = "https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html";
    try {
      let _0x4130e6 = await _0x161008(_0x19e318, _0x435ae3);
      await _0x2e97f5.sendMessage(_0x22febc.chat, {
        image: {
          url: _0x4130e6
        },
        caption: "" + _0x4528ad.success
      }, {
        quoted: _0x22febc
      });
    } catch (_0x2a133a) {
      console.error("Error in papercutstyle command:", _0x2a133a);
      _0x408906("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["pixelglitch"],
  operate: async ({
    m: _0x33e2fd,
    args: _0xf2df38,
    reply: _0x49a346,
    Cypher: _0xc8b853,
    prefix: _0x56f6c5,
    mess: _0x3edda5,
    ephoto: _0x324f19
  }) => {
    let _0x18cedf = _0xf2df38.join(" ");
    if (!_0x18cedf) {
      return _0x49a346("*Example: " + _0x56f6c5 + "pixelglitch Malvin*");
    }
    const _0x4f0a32 = "https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html";
    try {
      let _0x2ba569 = await _0x324f19(_0x4f0a32, _0x18cedf);
      await _0xc8b853.sendMessage(_0x33e2fd.chat, {
        image: {
          url: _0x2ba569
        },
        caption: "" + _0x3edda5.success
      }, {
        quoted: _0x33e2fd
      });
    } catch (_0x50981a) {
      console.error("Error in pixelglitch command:", _0x50981a);
      _0x49a346("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["royaltext"],
  operate: async ({
    m: _0x861bec,
    args: _0x1e8cbf,
    reply: _0x31ebb8,
    Cypher: _0x58aeaf,
    prefix: _0x14f711,
    mess: _0x5252bf,
    ephoto: _0x32ff1f
  }) => {
    let _0x46b83c = _0x1e8cbf.join(" ");
    if (!_0x46b83c) {
      return _0x31ebb8("*Example: " + _0x14f711 + "royaltext Matrix*");
    }
    const _0x10d8a9 = "https://en.ephoto360.com/royal-text-effect-online-free-471.html";
    try {
      let _0x3af035 = await _0x32ff1f(_0x10d8a9, _0x46b83c);
      await _0x58aeaf.sendMessage(_0x861bec.chat, {
        image: {
          url: _0x3af035
        },
        caption: "" + _0x5252bf.success
      }, {
        quoted: _0x861bec
      });
    } catch (_0x14036d) {
      console.error("Error in royaltext command:", _0x14036d);
      _0x31ebb8("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["sand"],
  operate: async ({
    m: _0x5ae01f,
    args: _0x30d620,
    reply: _0x5d764a,
    Cypher: _0x155292,
    prefix: _0x2ab71f,
    mess: _0x52048a,
    ephoto: _0x4b0134
  }) => {
    let _0xa5fa7f = _0x30d620.join(" ");
    if (!_0xa5fa7f) {
      return _0x5d764a("*Example: " + _0x2ab71f + "sand Matrix*");
    }
    const _0xd0f444 = "https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html";
    try {
      let _0x531360 = await _0x4b0134(_0xd0f444, _0xa5fa7f);
      await _0x155292.sendMessage(_0x5ae01f.chat, {
        image: {
          url: _0x531360
        },
        caption: "" + _0x52048a.success
      }, {
        quoted: _0x5ae01f
      });
    } catch (_0x4daaa8) {
      console.error("Error in sand command:", _0x4daaa8);
      _0x5d764a("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["summerbeach"],
  operate: async ({
    m: _0x1eb26e,
    args: _0x2ed23b,
    reply: _0x33934e,
    Cypher: _0x284d0c,
    prefix: _0x5a1b11,
    mess: _0x2f058e,
    ephoto: _0x2c3548
  }) => {
    let _0x25f958 = _0x2ed23b.join(" ");
    if (!_0x25f958) {
      return _0x33934e("*Example: " + _0x5a1b11 + "summerbeach Matrix*");
    }
    const _0x5323c0 = "https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html";
    try {
      let _0x4b6207 = await _0x2c3548(_0x5323c0, _0x25f958);
      await _0x284d0c.sendMessage(_0x1eb26e.chat, {
        image: {
          url: _0x4b6207
        },
        caption: "" + _0x2f058e.success
      }, {
        quoted: _0x1eb26e
      });
    } catch (_0x330be9) {
      console.error("Error in summerbeach command:", _0x330be9);
      _0x33934e("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["topography"],
  operate: async ({
    m: _0x63034a,
    args: _0x2207af,
    reply: _0x41d92a,
    Cypher: _0x4eb018,
    prefix: _0x1b7559,
    mess: _0x386ebe,
    ephoto: _0x1585bf
  }) => {
    let _0x1eb4cb = _0x2207af.join(" ");
    if (!_0x1eb4cb) {
      return _0x41d92a("*Example: " + _0x1b7559 + "topography Matrix*");
    }
    const _0x2f37fa = "https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html";
    try {
      let _0x612b24 = await _0x1585bf(_0x2f37fa, _0x1eb4cb);
      await _0x4eb018.sendMessage(_0x63034a.chat, {
        image: {
          url: _0x612b24
        },
        caption: "" + _0x386ebe.success
      }, {
        quoted: _0x63034a
      });
    } catch (_0x594858) {
      console.error("Error in topography command:", _0x594858);
      _0x41d92a("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["typography"],
  operate: async ({
    m: _0xee83ae,
    args: _0x1a6b24,
    reply: _0x332509,
    Cypher: _0x5e7ee6,
    prefix: _0x5678fa,
    mess: _0x54bb5e,
    ephoto: _0x35deb8
  }) => {
    let _0x48f82f = _0x1a6b24.join(" ");
    if (!_0x48f82f) {
      return _0x332509("*Example: " + _0x5678fa + "typography Matrix*");
    }
    const _0x1c9d68 = "https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html";
    try {
      let _0x1aa92a = await _0x35deb8(_0x1c9d68, _0x48f82f);
      await _0x5e7ee6.sendMessage(_0xee83ae.chat, {
        image: {
          url: _0x1aa92a
        },
        caption: "" + _0x54bb5e.success
      }, {
        quoted: _0xee83ae
      });
    } catch (_0x35019e) {
      console.error("Error in typography command:", _0x35019e);
      _0x332509("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["watercolortext"],
  operate: async ({
    m: _0x4690bb,
    args: _0x1db55b,
    reply: _0x5ecf92,
    Cypher: _0x44bd5f,
    prefix: _0xc002e,
    mess: _0x224eb5,
    ephoto: _0x688aab
  }) => {
    let _0x5740d8 = _0x1db55b.join(" ");
    if (!_0x5740d8) {
      return _0x5ecf92("*Example: " + _0xc002e + "watercolortext Matrix*");
    }
    const _0x16152d = "https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html";
    try {
      let _0x4b9de6 = await _0x688aab(_0x16152d, _0x5740d8);
      await _0x44bd5f.sendMessage(_0x4690bb.chat, {
        image: {
          url: _0x4b9de6
        },
        caption: "" + _0x224eb5.success
      }, {
        quoted: _0x4690bb
      });
    } catch (_0x47d68b) {
      console.error("Error in watercolortext command:", _0x47d68b);
      _0x5ecf92("*An error occurred while generating the effect.*");
    }
  }
}, {
  command: ["writetext"],
  operate: async ({
    m: _0x4d5e35,
    args: _0x5c899b,
    reply: _0x16e847,
    Cypher: _0x4ad0fb,
    prefix: _0x3039e3,
    mess: _0x24c96c,
    ephoto: _0x37cf42
  }) => {
    let _0x48dfd4 = _0x5c899b.join(" ");
    if (!_0x48dfd4) {
      return _0x16e847("*Example: " + _0x3039e3 + "writetext Matrix*");
    }
    const _0x37dd72 = "https://en.ephoto360.com/write-text-on-wet-glass-online-589.html";
    try {
      let _0x5240c5 = await _0x37cf42(_0x37dd72, _0x48dfd4);
      await _0x4ad0fb.sendMessage(_0x4d5e35.chat, {
        image: {
          url: _0x5240c5
        },
        caption: "" + _0x24c96c.success
      }, {
        quoted: _0x4d5e35
      });
    } catch (_0xa5b890) {
      console.error("Error in writetext command:", _0xa5b890);
      _0x16e847("*An error occurred while generating the effect.*");
    }
  }
}];