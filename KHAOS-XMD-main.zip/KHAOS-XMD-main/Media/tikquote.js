module.exports = [
  "https://vt.tiktok.com/ZSr9ba6qp/",
  "https://vt.tiktok.com/ZSr9b6RJp/",
  "https://vt.tiktok.com/ZSr9bBKnP/",
  "https://vt.tiktok.com/ZSr9bF7QC/",
  "https://vt.tiktok.com/ZSr9bUtyg/"
];