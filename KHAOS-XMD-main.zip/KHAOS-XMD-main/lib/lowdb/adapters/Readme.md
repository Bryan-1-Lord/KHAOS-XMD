kango bot don't clone
